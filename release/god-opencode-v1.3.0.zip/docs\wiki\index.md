# GOD-OPENCODE Wiki

> The single source of truth for GOD-OPENCODE — replacing scattered
> README sections with an organized, browseable reference.

Welcome. The wiki documents the system honestly, including the four
architectural concerns we're actively working on (see [Roadmap](roadmap.md)).

## Sections

| Page | What it covers |
|------|---------------|
| [Getting Started](getting-started.md) | 5 minutes: clone to first slash command |
| [Architecture](architecture.md) | Agents / skills / workflows + OpenCode integration |
| [Code Graph](graph.md) | Structural codebase mapping (new in 1.2) |
| [Dynamic Skills](dynamic-skills.md) | Per-request context pruning for skills (new in 1.2) |
| [Cross-Platform](cross-platform.md) | Linux / macOS / Windows / Docker install matrix |
| [Memory System](memory.md) | Long-term session + project memory (new in 1.2) |
| [Roadmap](roadmap.md) | Four open architectural concerns and how we're addressing them |

## How this wiki is built

The wiki is a `docs/wiki/` folder of Markdown files. There is no build
step. You can browse it directly in any markdown viewer, or open
`docs/wiki/index.md` in your editor.

The wiki is also surfaced via:
- TUI option `[8] Wiki` (or `W`)
- Dashboard nav link `Wiki`
- Inline links from agent prompts (e.g., `AGENTS.md` references 
  `docs/wiki/architecture.md`)

## Conventions

- Each page has a one-line purpose at the top.
- Code blocks show both the command and expected output where possible.
- "Current state" sections are kept honest — limited features are
  flagged as MVP, full solutions are linked in the Roadmap.

## See also

- [CHANGELOG.md](https://github.com/mattycigemp-crypto/GOD-OPENCODE/blob/master/CHANGELOG.md) — version history
- [README.md](https://github.com/mattycigemp-crypto/GOD-OPENCODE/blob/master/README.md) — one-page overview
- [AGENTS.md](https://github.com/mattycigemp-crypto/GOD-OPENCODE/blob/master/AGENTS.md) — context file for OpenCode
